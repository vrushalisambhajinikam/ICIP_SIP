package com.example.level1_musicapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    EditText name,pn,dp,email,en,pass1,pass2;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        pn=(EditText)findViewById(R.id.pn);
        email=(EditText)findViewById(R.id.email);
        pass1=(EditText)findViewById(R.id.pass1);
        pass2=(EditText) findViewById(R.id.pass2);
        register=(Button)findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Name=name.getText().toString();
                final String department=dp.getText().toString();
                final String phone=pn.getText().toString();
                final String emailid=email.getText().toString();
                final String enroll=en.getText().toString();
                final String password1=pass1.getText().toString();
                final String password2=pass2.getText().toString();

                if(Name.isEmpty()||department.isEmpty()||phone.isEmpty()||emailid.isEmpty()||enroll.isEmpty()||password1.isEmpty()||password2.isEmpty())
                {
                    Toast.makeText(Registration.this, "Please Fill All TextFild", Toast.LENGTH_SHORT).show();
                }
                else if(!password1.equals(password2))
                {
                    Toast.makeText(Registration.this, "Password are not Matching", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Register Data Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Registration.this, com.example.level1_musicapp.MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

}